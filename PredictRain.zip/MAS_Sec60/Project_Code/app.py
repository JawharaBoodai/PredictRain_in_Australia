import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle




app = Flask(__name__) #Initialize the flask App

@app.route('/cityinfo')
def cityinfo():
    return render_template('cityInfo.html')

@app.route('/')
def home():
    return render_template('homePage.html')

@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''

    model = pickle.load(open('lr_rainfall_model.pkl', 'rb'))
    enc_dic = pickle.load(open('encoder_dic.pkl', 'rb'))
    scaler = pickle.load(open('scaler.pkl', 'rb'))

    numerical_features = ['MinTemp','MaxTemp','Rainfall','Evaporation','Sunshine','WindGustSpeed','WindSpeed9am','WindSpeed3pm','Humidity9am','Humidity3pm','Pressure9am','Pressure3pm','Cloud9am','Cloud3pm','Temp9am','Temp3pm']

    categorical_features = ['Location', 'WindGustDir', 'WindDir9am', 'WindDir3pm',"RainToday"]
    num_val = []
    cat_val = []
    all_col = ['Location','MinTemp','MaxTemp','Rainfall','Evaporation','Sunshine','WindGustDir','WindGustSpeed','WindDir9am','WindDir3pm','WindSpeed9am','WindSpeed3pm','Humidity9am','Humidity3pm','Pressure9am','Pressure3pm','Cloud9am','Cloud3pm','Temp9am','Temp3pm','RainToday']
    all_val = []
    for i in all_col:
        if i in categorical_features:
            cat_val.append(enc_dic[i].transform([request.form.get(i)])[0])
            
        else:
            num_val.append(float(request.form.get(i)))
            
    num_val = scaler.transform([num_val])[0]
    print(num_val)
    for i in all_col:
        if i in categorical_features:
            all_val.append(cat_val[categorical_features.index(i)])
        elif i in numerical_features:
            all_val.append(num_val[numerical_features.index(i)])
        
    
    print (all_val) 
    final_features = np.array(all_val)
    
    prediction = model.predict([final_features])

    output = prediction[0]

    print (output)

    if output=="Yes":
        prediction_t="Yes, tomorrow is going to be a rainy day."
    elif output=="No":
        prediction_t = 'No, tomorrow is not going to be a rainy day.'

    return render_template('outputNo.html', prediction_text=prediction_t)

if __name__ == "__main__":
    app.run(port = 5000 ,debug=True)